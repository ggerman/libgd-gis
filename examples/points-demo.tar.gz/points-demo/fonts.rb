# ruby-libgd is evolving very fast, so some examples may temporarily stop working
# Please report issues or ask for help — feedback is very welcome
# https://github.com/ggerman/ruby-libgd/issues or ggerman@gmail.com

module GD
  module Fonts
    PATHS = [
      # Linux system fonts
      "/usr/share/fonts",
      "/usr/local/share/fonts",

      # macOS system fonts
      "/System/Library/Fonts",
      "/Library/Fonts",

      # User fonts
      File.expand_path("~/Library/Fonts"), # macOS user
      File.expand_path("~/.fonts")         # Linux user
    ].freeze

    EXT = "{ttf,otf,ttc}".freeze

    def self.all
      @all ||= PATHS.flat_map do |p|
        next [] unless Dir.exist?(p)
        Dir.glob("#{p}/**/*.#{EXT}")
      end.uniq
    end

    def self.random
      all.sample or raise "GD::Fonts: no fonts found on system"
    end

    def self.find(name)
      n = name.downcase
      all.find { |f| File.basename(f).downcase.include?(n) }
    end
  end
end

