# libgd-gis is evolving very fast, so some examples may temporarily stop working.
# Please report issues or ask for help — feedback is very welcome.
# https://github.com/ggerman/libgd-gis/issues or ggerman@gmail.com

require "gd/gis"
require "date"
require_relative "fonts" # this library get a random font from the system

def draw_legend(img)
  padding = 10
  x = 20
  y = 20
  w = 420
  h = 70

  bg = GD::Color.rgba(0,0,0,180)
  border = GD::Color.rgb(255,255,255)
  text1 = GD::Color.rgb(255,255,255)
  text2 = GD::Color.rgb(180,220,255)

  # fondo
  img.filled_rectangle(x, y, x+w, y+h, bg)
  img.rectangle(x, y, x+w, y+h, border)

  img.text(
    "libgd-gis v0.3.2",
    x: x + padding,
    y: y + 28,
    size: 20,
    color: text1,
    font: GD::Fonts.random
  )

  img.text(
    "Maps & cartography rendering for Ruby",
    x: x + padding,
    y: y + 52,
    size: 14,
    color: text2,
    font: GD::Fonts.random
  )
end

WORLD_BBOX = [-179.999, -85.0511, 179.999, 85.0511]
OUTPUT = "output/point-4.png"

map = GD::GIS::Map.new(
	bbox: WORLD_BBOX,
	zoom: 3,
	basemap: :cyclosm
)

map.style = GD::GIS::Style.load("solarized")

cities = [
  { lon: -58.3816, lat: -34.6037, name: "Buenos Aires" },
  { lon: -56.1645, lat: -34.9011, name: "Montevideo" },
  { lon: -70.6693, lat: -33.4489, name: "Santiago" },
  { lon: -74.0060, lat:  40.7128, name: "New York", icon: "icons/statue_of_liberty_new_york.png" },
  { lon: -118.2437, lat: 34.0522, name: "Los Angeles" },
  { lon: -99.1332, lat: 19.4326, name: "Mexico City" },
  { lon: -46.6333, lat: -23.5505, name: "São Paulo" },
  { lon: -43.1729, lat: -22.9068, name: "Rio de Janeiro", icon: "icons/christ_redeemer_rio.png" },
  { lon: -79.3832, lat:  43.6532, name: "Toronto" },
  { lon: -0.1276, lat: 51.5074, name: "London", icon: "icons/big_ben_london.png" },
  { lon:  2.3522, lat: 48.8566, name: "Paris", icon: "icons/eiffel_tower_paris.png" },
  { lon: 13.4050, lat: 52.5200, name: "Berlin" },
  { lon: 12.4964, lat: 41.9028, name: "Rome", icon: "icons/colosseum_rome.png" },
  { lon: -3.7038, lat: 40.4168, name: "Madrid" },
  { lon: 18.0686, lat: 59.3293, name: "Stockholm" },
  { lon: 16.3738, lat: 48.2082, name: "Vienna" },
  { lon: 31.2357, lat: 30.0444, name: "Cairo" },
  { lon: 18.4241, lat: -33.9249, name: "Cape Town" },
  { lon: 3.3792,  lat: 6.5244,  name: "Lagos" },
  { lon: 34.7818, lat: 32.0853, name: "Tel Aviv" },
  { lon: 44.3661, lat: 33.3152, name: "Baghdad" },
  { lon: 55.2708, lat: 25.2048, name: "Dubai" },
  { lon: 139.6917, lat: 35.6895, name: "Tokyo" },
  { lon: 116.4074, lat: 39.9042, name: "Beijing" },
  { lon: 121.4737, lat: 31.2304, name: "Shanghai" },
  { lon: 77.2090,  lat: 28.6139, name: "New Delhi" },
  { lon: 72.8777,  lat: 19.0760, name: "Mumbai" },
  { lon: 126.9780, lat: 37.5665, name: "Seoul" },
  { lon: 103.8198, lat: 1.3521,  name: "Singapore" },
  { lon: 151.2093, lat: -33.8688, name: "Sydney" },
  { lon: 144.9631, lat: -37.8136, name: "Melbourne" },
  { lon: 174.7633, lat: -36.8485, name: "Auckland" }
]


cities.each_with_index do |p, index|
    map.add_point(
        lon: p[:lon],
        lat: p[:lat],
        label: p[:name],
        icon: p[:icon]
    ) if p[:icon]

    if [true, false].sample
        map.add_point(
            lon: p[:lon],
            lat: p[:lat],
            label: p[:name],
            symbol: index
        ) 
    else
        map.add_point(
            lon: p[:lon],
            lat: p[:lat],
            label: p[:name],
            icon: "alphabetic",
            color: [6, 117, 196],
            font_color: [250, 250, 250],
            symbol: index
        )
    end unless p[:icon]
end


map.render

img = map.image
draw_legend(img)

img.save(OUTPUT)
puts "✔ Generated: #{OUTPUT}"