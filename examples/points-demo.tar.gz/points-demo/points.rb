# libgd-gis is evolving very fast, so some examples may temporarily stop working.
# Please report issues or ask for help — feedback is very welcome.
# https://github.com/ggerman/libgd-gis/issues or ggerman@gmail.com

require "gd/gis"
require "date"
require_relative "fonts" # this library get a random font from the system

def draw_legend(img)
  padding = 10
  x = 20
  y = 20
  w = 420
  h = 70

  bg = GD::Color.rgba(0,0,0,180)
  border = GD::Color.rgb(255,255,255)
  text1 = GD::Color.rgb(255,255,255)
  text2 = GD::Color.rgb(180,220,255)

  # fondo
  img.filled_rectangle(x, y, x+w, y+h, bg)
  img.rectangle(x, y, x+w, y+h, border)

  img.text(
    "libgd-gis v0.3.2",
    x: x + padding,
    y: y + 28,
    size: 20,
    color: text1,
    font: GD::Fonts.random
  )

  img.text(
    "Maps & cartography rendering for Ruby",
    x: x + padding,
    y: y + 52,
    size: 14,
    color: text2,
    font: GD::Fonts.random
  )
end

OUTPUT = "output/aerial.png"
GEOJSON = "data/aerial.geojson"

bbox = GD::GIS::Geometry.bbox_for_image(
  GEOJSON, 
  :zoom => 13, 
  :width => 800, 
  :height => 600, 
  :padding_px => 100
) 

map = GD::GIS::Map.new(
	bbox: bbox,
	zoom: 15,
	:width => 800,
	:height => 600,
	basemap: :osm
)

map.style = GD::GIS::Style.load("solarized")

map.add_geojson(GEOJSON)
map.render

img = map.image
draw_legend(img)

img.save(OUTPUT)
puts "✔ Generated: #{OUTPUT}"

