require "json"
require "gd/gis"

OUTPUT = "output/multi_line_string.png"

PARANA = [-60.58, -31.82, -60.49, -31.70]

map = GD::GIS::Map.new(
    bbox: PARANA,
    zoom: 14,
    basemap: :carto_light
)

map.style = GD::GIS::Style.load("light")
map.add_geojson("data/route.geojson")

map.render
map.save(OUTPUT)
puts "✔ Generated: #{OUTPUT}"